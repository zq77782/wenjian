 #进程是否运行
if pgrep -f "/home/container/gogo/goup server" > /dev/null; then
    echo "Hysteria 进程已在运行"
else
    echo "Hysteria 进程未运行，启动中..."
    /home/container/gogo/goup server -c /home/container/gogo/go.yaml >/dev/null 2>&1 &
    sleep 2  # 等待几秒以确保启动
    if pgrep -f "/home/container/gogo/goup server" > /dev/null; then
        echo "Hysteria 启动成功"
    else
        echo "Hysteria 启动失败"
    fi
fi
