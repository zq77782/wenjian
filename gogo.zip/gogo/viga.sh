#!/bin/sh

check_lun() {
    if pgrep -f "/home/container/gogo/goup server" > /dev/null; then
        echo "lun already running"
    else
        echo "lun The process is not running, starting..."
        /home/container/gogo/goup server -c /home/container/gogo/go.yaml > /dev/null 2>&1 &
        sleep 2
        if pgrep -f "/home/container/gogo/goup server" > /dev/null; then
            echo "lun Startup Success"
        else
            echo "lun Startup failure"
        fi
    fi
}


while true; do
    check_lun
    sleep 60
done