#!/bin/bash
while true; do
    /bin/bash /home/container/gogo/go.sh >/dev/null 2>&1 &
    sleep 60 # 5 fen 300
done &
sleep infinity